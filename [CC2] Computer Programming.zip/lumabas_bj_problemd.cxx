/* Name: Bryan Jay M. Lumabas
 * Date: 10.12.2024
 * Problem: Create a program that will calculate the area of a trapezoid given the measurement of its first and second base and its height. You can refer to the given below: [A = (a + b)/2 * h]. Where A is area; a and b are the bases and h is height.
 * Purpose: A Solution for Problem D thus, so far, this is definitely nakakabuang na Sir. Jholan.
*/

#include <iostream>
using namespace std;

double calculate_area(double base1, double base2, double height) {
return ((base1 + base2) / 2) * height; }

int main() {
	     double base1, base2, height;
	     
	 cout << " Please! Enter the first base (a):   ";
	 cin >> base1;
	 cout << "Please! Enter the second base (b):   ";
	 cin >> base2;
	 cout << "Please! Enter the height (h):   ";
	 cin >> height;
	     double area = calculate_area(base1, base2, height);
	cout << "The area of the trapezoid is:  " << area << endl;
	
return 0; }