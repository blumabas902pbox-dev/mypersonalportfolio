/* Name: Bryan Jay M. Lumabas
 * Date: 10.10.2024
 * Problem: Create a program that will ask the user to input a number then display as output the 30% of that number.
 *Purpose: A Solution for Problem B as 30% ratio per se.
*/

#include <iostream>

using namespace std;
int main() {
	
	float num;
	
	cout << "Please! Enter a number: ";
	cin >> num;
	
	float result  = num * .30;
	cout << " The 30% of " << num << " is: " << result << endl;
	
return 0; }