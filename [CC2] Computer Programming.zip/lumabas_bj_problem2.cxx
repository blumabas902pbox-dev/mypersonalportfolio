/*Name: Bryan Jay M. Lumabas
 *Date: 11.15.2024
 *Problem: Write a program that prompts the user to input the shape type such as circle, rectangle, and rectangular prism and the appropriate dimension of the shape. The program then outputs the following information about the shape: For circle, it outputs the area and circumference; for rectangle, outputs the perimeter and area, and for a rectangular prism, outputs the volume and the surface area.
 *Purpose: A solution for Problem 2, identifying and emphasizing the shape types. Where you reiterates or revise something in your life. Living were never the same before and affects its entirely. Something is incomplete. Made by obscure insecurities. */

#include <iostream>
#include <cmath>

using namespace std;
int main() {
	string shape;
	cout << "The available shapes are circle, rectangle, and prism.      Please! Choose and pick a shape:  ";
	cin >> shape;
	
	if (shape == "circle") {
	    double radius;
	    cout << "Input the measurement of the radius:  ";
	    cin >> radius;
	    
	    double circumference = 2 * M_PI *radius;
	    double area = M_PI * radius * radius;
	    
	    cout << "The circumference is " << circumference << " units." << endl;
	    cout << "The area of the circle is " << area << " units squared." << endl; }
	    
    else if (shape == "rectangle") {
        double length, width;
        cout << "Input the measurement of the length" << " and the width:  ";
        cin >> length >> width;
        
        double perimeter = 2 * (length * width);
        double area = length * width;
        
        cout << "The perimeter is " << perimeter << " units." << endl; 
        cout << "The area of the rectangle is " << area << " units squared." << endl; }
        
    else if (shape == "prism") {
        double length, width, height;
        
        cout << "Input the measurement of the length " << " width " << " and height:  ";
        cin >> length >> width >> height;
        
        double volume = length * width * height;
        
        cout << "The volume of the rectangular prism is " << volume << " units cubed." << endl; }
        
else {
        cout << "The shape you type is invalid. Please! Refer to the available shapes above. Thank you." << endl; }
      	    
	return 0; } 