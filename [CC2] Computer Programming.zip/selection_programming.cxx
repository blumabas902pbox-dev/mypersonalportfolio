// Programmer: Bryan Jay M. Lumabas
// Date: 10.04.2024
// Purpose: For Practical Examination
// Type of Program: Selection
// Problem: Write a program with a choices from A to D.



#include <iostream>
#include <cctype>

using namespace std;

int main()
{
     char choice;
     
     cout << "Choose an option my fellow BSIT-1Ds (A, B, C, or D):" << endl;
     
     cout << "Option A. An IT students will always find the way." << endl;
     
     cout << "Option B. Beats me! For the sake of your dreams. " << endl;
     
     cout << "Option C. Can't focus, classmates I know I can count on you." << endl;
     
     cout << "Option D. Doesn't matter, I shift a course anyway." << endl;
     
     cout << "Enter your choice:" ;
             cin >> choice;             

}    
    (static_cast<char> (toupper(choice)))
                                        
{
              case 'A':
                      cout << "You choose Option A." << endl;
                      break;
              case 'B':
                      cout << "You choose Option B." << endl;
                      break;
              case 'C':
                      cout << "You choose Option C." << endl;
                      break;
              case 'D':
                      cout << "You choose Option D." << endl;
                      break;
              default:
                      cout << "Invalid choice. Please select A, B, C, or D" << endl;
            
            return 0;
            
}