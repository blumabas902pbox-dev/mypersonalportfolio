/* Name: Bryan Jay M. Lumabas
 * Date: 10.11.2024
 * Problem: Create a program that will ask the user to input the measurement of the side of a cube then display its volume and surface area as output.
 *Purpose: A Solution for Problem C as cube pointed out side to side.
 */

#include <iostream>
using namespace std;
int main() {
	float side;
	cout << "Please! Enter the side length of a cube: ";
	cin >> side;
	
	float volume = side * side * side;
	float surface_area = (side * side);
	
	cout << " The volume of the cube is: " << volume << endl; 
	cout << " The surface area of the cube is: " << surface_area << endl;
	
return 0; }