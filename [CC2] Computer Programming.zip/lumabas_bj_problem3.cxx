/*Name: Bryan Jay M. Lumabas
 *Date: 11.15.2024
 *Problem: Write a program that prompts the user to enter an integer for today's day of the week (Sunday is 0, Monday is 1, Tuesday is 2, Wednesday is 3, Thursday is 4, Friday is 5, and Saturday is 6). Also, prompt the user to enter the number of days after day for a future day and display the name of day today the future day of the week.
 *Purpose: A solution for Problem 3, let's say I have a debt and the weekly amortization is today. Then, days after that I must pay for the next week. Count one to seven or add by seven for a week then the result is November 22, Friday. Just like a task given in an online classroom, you must turn in before the due.*/

#include <iostream>

using namespace std;

int main() {
	int today, daysAfter;
	
	cout << "Input today's day:  ";
	cin >> today;
	
	if (today < 0 || today > 6) {
	    cout << "Invalid input for today's day." << endl;
	    return 1; }
	    
	    cout << "Input the number of days elapsed since since today:  ";
	    cin >> daysAfter;
	    
	    int futureDay = (today + daysAfter) % 7;
	    
	    string daysOfWeek[]={ "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };
	    
	    cout << "Today is " << daysOfWeek[today] << " and the future day is " <<daysOfWeek[futureDay] << "." <<
	 endl;
	 
	 return 0; }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	