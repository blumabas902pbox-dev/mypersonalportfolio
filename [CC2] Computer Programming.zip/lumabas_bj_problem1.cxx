/*Name: Bryan Jay M. Lumabas
 *Date: 11.14.2024
 *Problem: Write a program that mimics a calculator. The program should take as input two numbers and the operation to be performed. If should then the output the numbers, the operator, and the result. (For division, if the divisor is zero, output an appropriate message.)
 *Purpose: A solution for Problem 1, mimicking a calculator. Where a different vibes inflicted the healthy relationship.*/

#include <iostream>
using namespace std;
int main() {
	    double num1, num2;
	    char operation;
	    
	    cout << "Input the first number " << "and the second number " << "and an operator (+, -, *, /):  ";
	    cin >> num1 >> num2 >> operation;
	    
	        switch (operation) {
	             case '+':
	                    cout << "The sum of " << num1 << " and " << num2 << " is equal to " << (num1 + num2) << "." << endl;
	                    break;
	             case '-':
	                     cout << "The difference of " << num1 << " minus " << num2 << " is equal to " << (num1 - num2) << "." << endl;
	                     break;
	             case '*':
	                     cout << "The product of " << num1 << " multiplied by " << num2 << " is equal to " << (num1 * num2) << "." << endl;
	                     break;
	             case ('/'):
	             
	                     if (num2 == 0) {
	                             cout << "Division by zero is undefined. " << endl; }
	                     else {
	                             cout << "The quotient of divided " << num1 << " by " << num2 << " is equal to " << (num1/num2) << "." << endl; }
	                     break;
	              default:
	                     cout << "Your input is invalid. Please! Enter 2 number digit(s) first and just pick one of (+, -, *, or /) operator." << endl; }
	                  
	return 0; }