/* Name: Bryan Jay M. Lumabas
 * Date: 10.10.2024
 * Problem: Create a problem that will ask the users' name and print it 4 times. You should not use repetition control structure in solving this solution.
 * Purpose: A solution for Problem A is applicable for double name.
*/


#include <iostream>
#include <string>
using namespace std;
int main() {
	std:: string doubleName;
	std:: cout << "Please! Enter your name: ";
	std::getline(std::cin, doubleName);
 	
	std:: cout << doubleName << std::endl;
	std:: cout << doubleName << std::endl;
	std:: cout << doubleName << std::endl;
	std:: cout << doubleName << std::endl;
	return 0; }