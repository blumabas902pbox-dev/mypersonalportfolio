/* Name: Bryan Jay M. Lumabas
 * Date: 10.12.2024
 * Problem: Create a program that will calculate that total surface area of a cylinder given the measurement of its diameter and height. You can refer to the formula presented below:     [SA=_r( r+h)]. Where SA is a surface area; r is the radius of the cylinder and h is the height.
 * Purpose: A Solution for Problem E, ma-eevict na yata ko. Mapapashift ako neto.
*/
 
#include <iostream>
#include <cmath>
using namespace std;

double calculate_surface_area(double diameter, double height) {
    double radius = diameter / 2;
    return M_PI * radius * (radius + height); }
    
int main() {
	double diameter, height;
	cout << "Please! Enter the diameter of the cylinder:   ";
	cin >> diameter;	
	cout << "Please! Enter the height of the cylinder:   ";
	cin >> height;
	
	double surface_area = calculate_surface_area(diameter, height);	
	cout << "The total surface area of the cylinder is:   " <<
	 surface_area << endl;	 
return 0; }