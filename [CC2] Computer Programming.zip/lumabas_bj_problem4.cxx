/*Name: Bryan Jay M. Lumabas
 *Date: 11.15.2024
 *Problem: Write a program that prompts the user to enter the speed of a vehicle. If speed is less than 20, display too slow; if speed is greater than 80, then, display too fast. Otherwise, display just right.
 *Purpose: A solution for Problem 4, how speed works is vital for driving a vehicle. Where the speed rubrics of attachment for someone how fast to collide, but I must hit the stacks first. */

#include <iostream>
using namespace std;

int main() {
	int speed;
	cout << "Input the speed of the vehicle(km/h): ";
	cin >> speed;
	
	if (speed < 20) {
	    cout << "Too slow!" << endl; }
	else if (speed > 80) {
	    cout << "Too fast!" << endl; }
	else {
	    cout << "It's speed just right!" << endl; }
	return 0; }